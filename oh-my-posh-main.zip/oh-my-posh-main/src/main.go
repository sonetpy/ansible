package main

import "github.com/jandedobbeleer/oh-my-posh/src/cli"

func main() {
	cli.Execute()
}
