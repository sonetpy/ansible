package shell

const (
	ZSH     = "zsh"
	BASH    = "bash"
	PWSH    = "pwsh"
	FISH    = "fish"
	PWSH5   = "powershell"
	CMD     = "cmd"
	NU      = "nu"
	GENERIC = "shell"
	TCSH    = "tcsh"
	ELVISH  = "elvish"
	XONSH   = "xonsh"
)
