//go:build windows && !386

package constants

const (
	DotnetExitCode = int(0x80008091)
)
