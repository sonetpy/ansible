//go:build windows && 386

package constants

const (
	DotnetExitCode = -2147450735
)
