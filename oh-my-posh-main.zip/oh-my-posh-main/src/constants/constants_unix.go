//go:build !windows

package constants

const (
	DotnetExitCode = 142
)
